import requests
import sqlite3
import time
from random import randint
from time import sleep
from itertools import cycle

from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from lxml.html import fromstring


def get_proxies():
    """Получает список бесплатных HTTPS-прокси"""
    url = 'https://free-proxy-list.net/'
    try:
        response = requests.get(url, timeout=30)
        parser = fromstring(response.text)
        proxies = set()
        for i in parser.xpath('//tbody/tr')[:50]:
            if i.xpath('.//td[7][contains(text(),"yes")]'):
                proxy = ":".join([i.xpath('.//td[1]/text()')[0], i.xpath('.//td[2]/text()')[0]])
                proxies.add(proxy)
        return list(proxies)
    except Exception as e:
        print(f"❌ Ошибка получения прокси: {e}")
        return []


def search_drug_on_irecommend(drug_name, use_proxy=False):
    """Ищет препарат и возвращает URL страницы с отзывами (первый результат)"""
    ua = UserAgent()
    headers = {
        'User-Agent': ua.random,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }

    search_url = f"https://irecommend.ru/srch?query={drug_name}"
    print(f"🔍 Поиск: {search_url}")

    proxy_pool = None
    if use_proxy:
        proxies = get_proxies()
        if proxies:
            proxy_pool = cycle(proxies)

    for attempt in range(3):
        try:
            sleep(randint(5, 8))

            if use_proxy and proxy_pool:
                proxy = next(proxy_pool)
                response = requests.get(search_url, headers=headers, proxies={'http': proxy, 'https': proxy},
                                        timeout=30)
            else:
                response = requests.get(search_url, headers=headers, timeout=30)

            if response.status_code != 200:
                print(f"   ⚠️ Попытка {attempt + 1}: статус {response.status_code}")
                continue

            soup = BeautifulSoup(response.text, 'lxml')

            # Находим первый результат
            product_tizer = soup.select_one('.srch-result-nodes .ProductTizer')
            if not product_tizer:
                print("❌ Результаты не найдены")
                return None

            title_link = product_tizer.select_one('.title a')
            if not title_link:
                print("❌ Не найдена ссылка на препарат")
                return None

            product_url = title_link.get('href')
            if not product_url.startswith('http'):
                product_url = f"https://irecommend.ru{product_url}"

            print(f"✅ Найдена страница препарата: {product_url}")
            return product_url

        except Exception as e:
            print(f"   ⚠️ Попытка {attempt + 1} ошибка: {e}")
            continue

    print(f"❌ Не удалось найти страницу препарата '{drug_name}'")
    return None


def get_review_links_from_page(page_url, use_proxy=False):
    """Собирает ссылки на отзывы со страницы препарата"""
    ua = UserAgent()
    headers = {
        'User-Agent': ua.random,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }

    proxy_pool = None
    if use_proxy:
        proxies = get_proxies()
        if proxies:
            proxy_pool = cycle(proxies)

    try:
        sleep(randint(5, 8))

        if use_proxy and proxy_pool:
            proxy = next(proxy_pool)
            response = requests.get(page_url, headers=headers, proxies={'http': proxy, 'https': proxy}, timeout=30)
        else:
            response = requests.get(page_url, headers=headers, timeout=30)

        if response.status_code != 200:
            print(f"   ❌ Ошибка загрузки: {response.status_code}")
            return []

        soup = BeautifulSoup(response.text, 'lxml')

        review_links = []
        for link in soup.find_all('a', href=True):
            href = link.get('href', '')
            # Ищем ссылки на отзывы (содержат /content/ и не содержат page=)
            if '/content/' in href and 'page=' not in href:
                if href == page_url or href == page_url.rstrip('/'):
                    continue
                full_url = href if href.startswith('http') else f"https://irecommend.ru{href}"
                if full_url not in review_links and 'reviews' not in full_url:
                    review_links.append(full_url)

        print(f"📊 Найдено ссылок на отзывы: {len(review_links)}")
        return review_links

    except Exception as e:
        print(f"   ❌ Ошибка: {e}")
        return []


def parse_review_page(review_url, use_proxy=False):
    """Парсит страницу отзыва"""
    ua = UserAgent()
    headers = {
        'User-Agent': ua.random,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }

    proxy_pool = None
    if use_proxy:
        proxies = get_proxies()
        if proxies:
            proxy_pool = cycle(proxies)

    try:
        sleep(randint(8, 12))

        if use_proxy and proxy_pool:
            proxy = next(proxy_pool)
            response = requests.get(review_url, headers=headers, proxies={'http': proxy, 'https': proxy}, timeout=30)
        else:
            response = requests.get(review_url, headers=headers, timeout=30)

        if response.status_code != 200:
            return None

        soup = BeautifulSoup(response.text, 'lxml')

        # Заголовок
        title = ""
        title_elem = soup.select_one('.reviewTitle')
        if title_elem:
            title = title_elem.text.strip()

        # Текст отзыва
        review_text = ""
        text_elem = soup.select_one('.description[itemprop="reviewBody"]')
        if text_elem:
            review_text = text_elem.text.strip()

        # Достоинства
        plus = ""
        plus_items = soup.select('.plus ul li span[itemprop="name"]')
        if plus_items:
            plus = "\n".join([item.text.strip() for item in plus_items])

        # Недостатки (важны для побочек)
        minus = ""
        minus_items = soup.select('.minus ul li span[itemprop="name"]')
        if minus_items:
            minus = "\n".join([item.text.strip() for item in minus_items])

        # Вердикт
        verdict = ""
        verdict_elem = soup.select_one('.conclusion .verdict')
        if verdict_elem:
            verdict = verdict_elem.text.strip()

        # Опыт использования
        usage_experience = ""
        exp_label = soup.find(text='Опыт использования:')
        if exp_label:
            parent = exp_label.find_next('div', class_='item-data')
            if parent:
                usage_experience = parent.text.strip()

        # Формируем полный текст
        full_text = f"{title}\n\n{review_text}\n\nДостоинства: {plus}\n\nНедостатки: {minus}\n\nВердикт: {verdict}\n\nОпыт использования: {usage_experience}"

        return {
            'text': full_text[:5000],
            'review_text': review_text[:3000],
            'url': review_url,
            'title': title,
            'plus': plus,
            'minus': minus,
            'verdict': verdict,
            'usage_experience': usage_experience
        }

    except Exception as e:
        print(f"   ❌ Ошибка: {e}")
        return None


def save_review_to_db(drug_name, review_data, db_path='medical_data.db'):
    """Сохраняет отзыв в базу данных"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute('SELECT id FROM medicines WHERE medicine_name = ?', (drug_name.lower(),))
    result = cursor.fetchone()

    if not result:
        conn.close()
        return False

    medicine_id = result[0]
    review_url = review_data.get('url')

    full_text = f"""Заголовок: {review_data.get('title', '')}

Текст отзыва: {review_data.get('review_text', '')}

Достоинства: {review_data.get('plus', '')}

Недостатки: {review_data.get('minus', '')}

Вердикт: {review_data.get('verdict', '')}

Опыт использования: {review_data.get('usage_experience', '')}"""

    if review_url:
        existing = cursor.execute('''
            SELECT 1 FROM reviews WHERE medicine_id = ? AND url = ?
        ''', (medicine_id, review_url)).fetchone()
        if existing:
            conn.close()
            return False

    try:
        cursor.execute('''
            INSERT INTO reviews (medicine_id, review_text, source, url)
            VALUES (?, ?, ?, ?)
        ''', (medicine_id, full_text[:5000], 'irecommend', review_url))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Ошибка сохранения: {e}")
        conn.close()
        return False


def parse_drug_reviews(drug_name, max_reviews=20, use_proxy=True):
    """Главная функция парсинга"""
    print(f"\n{'=' * 60}")
    print(f"🔍 Парсинг отзывов для '{drug_name}'")
    print(f"{'=' * 60}")
    print(f"🔑 Использование прокси: {'Да' if use_proxy else 'Нет'}")

    # 1. Находим страницу препарата
    drug_page_url = search_drug_on_irecommend(drug_name, use_proxy=use_proxy)

    if not drug_page_url:
        print(f"❌ Не найдена страница препарата '{drug_name}'")
        return 0

    # 2. Собираем ссылки на отзывы
    print(f"\n📄 Сбор ссылок на отзывы...")
    review_links = get_review_links_from_page(drug_page_url, use_proxy=use_proxy)

    if not review_links:
        print(f"❌ Не найдено отзывов")
        return 0

    print(f"📊 Найдено ссылок на отзывы: {len(review_links)}")

    # 3. Парсим отзывы
    saved = 0
    for i, link in enumerate(review_links[:max_reviews]):
        print(f"\n   [{i + 1}/{min(max_reviews, len(review_links))}]")

        review_data = parse_review_page(link, use_proxy=use_proxy)

        if review_data and review_data.get('review_text'):
            if save_review_to_db(drug_name, review_data):
                saved += 1
                print("      ✅ Сохранён")
                if review_data.get('minus'):
                    print(f"      📝 Минусы: {review_data['minus'][:100]}...")
            else:
                print("      ⚠️ Уже есть в БД")
        else:
            print("      ❌ Не удалось спарсить")

    print(f"\n📊 ИТОГО сохранено: {saved} отзывов для '{drug_name}'")
    return saved