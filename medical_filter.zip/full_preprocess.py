"""
ПРЕДВАРИТЕЛЬНАЯ ОБРАБОТКА (запустить ОДИН раз):
1. Парсит отзывы для каждого препарата
2. Прогоняет через rubioroberta (проверка медтерминов)
3. Обрабатывает текст (нормализация, извлечение кандидатов)
4. Сохраняет результаты в БД
"""
from database_work import init_db
import sqlite3
import json
import os
import re
from random import randint
from time import sleep
from collections import defaultdict
from typing import List, Dict, Tuple, Optional

import pymorphy2
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

from working_with_text import normalize_phrase, clean_text_for_side_effects, STOP_WORDS
from website_parser import parse_drug_reviews
from database_work import save_processed_sentence, save_candidate_symptom

DB_PATH = 'medical_data.db'
JSON_PATH = 'side_e_dataset.json'
MODEL_PATH = "./rubioroberta_side_effect_classifier"

# Загружаем модель один раз
print("🔄 Загрузка модели rubioroberta...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_PATH)
print("✅ Модель загружена")

morph = pymorphy2.MorphAnalyzer()

BAD_ADJECTIVES = {
    'ужасный', 'жуткий', 'страшный', 'сильный', 'слабый',
    'большой', 'маленький', 'плохой', 'хороший', 'обычный',
    'постоянный', 'временный', 'редкий', 'частый'
}


def is_medical_term(text: str) -> bool:
    """Проверка медицинского термина моделью rubioroberta"""
    if not text or len(text) < 3:
        return False

    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=128)
    with torch.no_grad():
        outputs = model(**inputs)

    return torch.argmax(outputs.logits, dim=1).item() == 1


def split_sentences(text: str) -> List[str]:
    """Разбивает текст на предложения"""
    if not text:
        return []
    parts = re.split(r"[.!?\n;:]+", text)
    return [p.strip() for p in parts if p.strip() and len(p.strip()) > 15]


def normalize_word(word: str) -> Tuple[str, str]:
    """Нормализует слово"""
    try:
        parsed = morph.parse(word)[0]
        return parsed.normal_form, parsed.tag.POS
    except Exception:
        return word, None


def extract_candidates_from_sentence(sentence: str, medicine_name: str = None) -> List[Tuple[str, str]]:
    """
    Извлекает кандидатов из предложения
    Возвращает список (нормализованный, оригинальный)
    """
    original_sentence = sentence
    sentence = re.sub(r"[^\w\s-]", " ", sentence.lower())
    raw_words = sentence.split()
    original_words = original_sentence.lower().split()

    medicine_norm = normalize_phrase(medicine_name) if medicine_name else ""
    medicine_words = set(medicine_norm.split())

    words = []
    pos_tags = []
    original_forms = []

    for i, word in enumerate(raw_words):
        word = word.strip("-")
        orig_word = original_words[i].strip("-") if i < len(original_words) else word

        if len(word) < 3:
            continue
        if word in STOP_WORDS:
            continue

        normalized, pos = normalize_word(word)

        if len(normalized) < 3:
            continue
        if normalized in STOP_WORDS:
            continue
        if medicine_words and normalized in medicine_words:
            continue
        if pos not in {"NOUN", "ADJF", "ADJS"}:
            continue
        if pos in {"ADJF", "ADJS"} and normalized in BAD_ADJECTIVES:
            continue

        words.append(normalized)
        pos_tags.append(pos)
        original_forms.append(orig_word)

    candidates = []

    for i, (word, pos) in enumerate(zip(words, pos_tags)):
        # Одиночные существительные
        if pos == "NOUN":
            candidates.append((word, original_forms[i]))

        # Биграммы
        if i < len(words) - 1:
            w1, p1 = words[i], pos_tags[i]
            w2, p2 = words[i + 1], pos_tags[i + 1]
            orig1, orig2 = original_forms[i], original_forms[i + 1]

            if p1 in {"ADJF", "ADJS"} and p2 == "NOUN":
                candidates.append((f"{w1} {w2}", f"{orig1} {orig2}"))
            elif p1 == "NOUN" and p2 == "NOUN":
                candidates.append((f"{w1} {w2}", f"{orig1} {orig2}"))

    # Убираем дубликаты
    unique = {}
    for norm, orig in candidates:
        if norm not in unique:
            unique[norm] = orig
        elif len(orig) > len(unique[norm]):
            unique[norm] = orig

    return [(norm, orig) for norm, orig in unique.items()]


def process_single_review(medicine_id: int, medicine_name: str, review_text: str):
    """
    Обрабатывает один отзыв:
    1. Разбивает на предложения
    2. Для каждого предложения проверяет моделью
    3. Извлекает кандидаты
    4. Сохраняет в БД
    """
    if not review_text or len(review_text) < 50:
        return

    sentences = split_sentences(review_text)

    for sentence in sentences:
        normalized = normalize_phrase(sentence)

        sentence_id = save_processed_sentence(
            medicine_id,
            sentence,
            sentence,
            normalized
        )

        candidates = extract_candidates_from_sentence(sentence, medicine_name)

        for candidate_norm, candidate_orig in candidates:
            is_medical = is_medical_term(candidate_norm)

            if is_medical:
                save_candidate_symptom(
                    medicine_id,
                    sentence_id,
                    candidate_norm,
                    candidate_orig,
                    is_medical
                )
                print(f"            ✅ Медтермин: {candidate_orig}")


def load_drugs_from_json() -> List[Dict]:
    """Загружает препараты из JSON"""
    if not os.path.exists(JSON_PATH):
        print(f"❌ Файл {JSON_PATH} не найден")
        return []

    with open(JSON_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)

    drugs = []
    for item in data:
        drug_name = item.get('drug_name_ru', '').strip().lower()
        if drug_name and len(drug_name) > 2:
            drugs.append({'name': drug_name})

    print(f"📖 Загружено {len(drugs)} препаратов из JSON")
    return drugs


def get_drug_id_from_db(drug_name: str) -> Optional[int]:
    """Получает ID препарата из БД"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM medicines WHERE medicine_name = ?', (drug_name,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None


def get_existing_processed_sentences_count(drug_id: int) -> int:
    """Сколько уже обработанных предложений для препарата"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM processed_sentences WHERE medicine_id = ?', (drug_id,))
    count = cursor.fetchone()[0]
    conn.close()
    return count


def process_all_drugs(max_reviews_per_drug: int = 15, parse_new_reviews: bool = True):
    """
    ГЛАВНАЯ ФУНКЦИЯ: полная предобработка всех препаратов
    """
    print("=" * 70)
    print("🚀 ЗАПУСК ПРЕДВАРИТЕЛЬНОЙ ОБРАБОТКИ")
    print("=" * 70)

    drugs = load_drugs_from_json()
    if not drugs:
        print("❌ Нет препаратов для обработки")
        return

    stats = {'total_processed': 0, 'total_sentences': 0, 'total_candidates': 0}

    for i, drug_info in enumerate(drugs):
        drug_name = drug_info['name']

        print(f"\n{'=' * 50}")
        print(f"[{i+1}/{len(drugs)}] Обработка: {drug_name}")
        print(f"{'=' * 50}")

        drug_id = get_drug_id_from_db(drug_name)
        if not drug_id:
            print(f"   ❌ Препарат не найден в БД! Сначала импортируйте его через import_side_effects.py")
            continue

        existing_count = get_existing_processed_sentences_count(drug_id)

        if existing_count > 0:
            print(f"   ✅ Уже обработано {existing_count} предложений, пропускаем")
            continue

        if parse_new_reviews:
            print(f"   📝 Парсинг отзывов...")
            saved = parse_drug_reviews(drug_name, max_reviews=max_reviews_per_drug, use_proxy=False)
            print(f"   📊 Сохранено отзывов: {saved}")

            if saved == 0:
                print(f"   ⚠️ Нет отзывов для этого препарата")
                continue

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT review_text FROM reviews WHERE medicine_id = ?', (drug_id,))
        reviews = [row[0] for row in cursor.fetchall() if row[0]]
        conn.close()

        if not reviews:
            print(f"   ⚠️ Нет отзывов для обработки")
            continue

        print(f"   📊 Всего отзывов: {len(reviews)}")
        print(f"   🔍 Обработка отзывов (извлечение медтерминов)...")
        sentence_count = 0

        for review_idx, review_text in enumerate(reviews):
            if review_idx % 5 == 0:
                print(f"      Прогресс: {review_idx+1}/{len(reviews)} отзывов")

            sentences_before = len(split_sentences(review_text))
            sentence_count += sentences_before

            process_single_review(drug_id, drug_name, review_text)

        stats['total_processed'] += 1
        stats['total_sentences'] += sentence_count

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM candidate_symptoms WHERE medicine_id = ?', (drug_id,))
        candidate_count = cursor.fetchone()[0]
        conn.close()
        stats['total_candidates'] += candidate_count

        print(f"   ✅ Готово! Предложений: {sentence_count}, Медтерминов: {candidate_count}")

        sleep(randint(3, 5))

    print("\n" + "=" * 70)
    print("📊 ИТОГОВАЯ СТАТИСТИКА:")
    print(f"   ✅ Обработано препаратов: {stats['total_processed']}")
    print(f"   📝 Всего предложений: {stats['total_sentences']}")
    print(f"   🔗 Всего медтерминов: {stats['total_candidates']}")
    print("=" * 70)
    print("\n🎉 Теперь можно запускать сайт! Все данные уже в БД.")


if __name__ == '__main__':
    import sys

    init_db()

    if len(sys.argv) > 1:
        drug_name = ' '.join(sys.argv[1:])
        drug_id = get_drug_id_from_db(drug_name.lower())
        if drug_id:
            print(f"🔄 Обработка препарата: {drug_name}")
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute('SELECT review_text FROM reviews WHERE medicine_id = ?', (drug_id,))
            reviews = [row[0] for row in cursor.fetchall() if row[0]]
            conn.close()

            for review in reviews:
                process_single_review(drug_id, drug_name, review)
            print("✅ Готово!")
        else:
            print(f"❌ Препарат '{drug_name}' не найден в БД")
    else:
        process_all_drugs(max_reviews_per_drug=15, parse_new_reviews=True)